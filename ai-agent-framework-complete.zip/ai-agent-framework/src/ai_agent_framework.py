#!/usr/bin/env python3
"""
AI Agent Framework - Built from First Principles
Based on the ReAct (Reason + Act) pattern with OpenRouter integration

This implementation follows the guide provided, with enhancements for:
- Top 100 OpenRouter models integration
- Robust tool management
- Error handling and retry logic
- Extensible tool system
"""

import os
import re
import json
import time
import logging
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass
from openai import OpenAI
import requests
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class ToolResult:
    """Result from tool execution"""
    success: bool
    result: str
    error: Optional[str] = None

class ToolRegistry:
    """Registry for managing available tools"""
    
    def __init__(self):
        self.tools: Dict[str, Callable] = {}
        self.schemas: Dict[str, str] = {}
        
    def register_tool(self, name: str, func: Callable, schema: str):
        """Register a new tool"""
        self.tools[name] = func
        self.schemas[name] = schema
        logger.info(f"Registered tool: {name}")
    
    def get_tool_schemas(self) -> str:
        """Get formatted tool schemas for the LLM"""
        schemas = ["Available Tools:"]
        for i, (name, schema) in enumerate(self.schemas.items(), 1):
            schemas.append(f"{i}. {schema}")
        return "\n".join(schemas)
    
    def execute_tool(self, name: str, **kwargs) -> ToolResult:
        """Execute a tool with given parameters"""
        if name not in self.tools:
            return ToolResult(False, "", f"Tool '{name}' not found")
        
        try:
            result = self.tools[name](**kwargs)
            return ToolResult(True, str(result))
        except Exception as e:
            logger.error(f"Error executing tool {name}: {e}")
            return ToolResult(False, "", str(e))

# Initialize tool registry
tool_registry = ToolRegistry()

# ============================================================================
# CORE TOOLS IMPLEMENTATION
# ============================================================================

def write_file(filename: str, content: str) -> str:
    """Write content to a file"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)
        return f"Successfully wrote content to {filename}"
    except Exception as e:
        return f"Error writing to file: {e}"

def read_file(filename: str) -> str:
    """Read content from a file"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
        return f"File content:\n{content}"
    except Exception as e:
        return f"Error reading file: {e}"

def search_web(query: str) -> str:
    """Search the web for information"""
    # This is a placeholder - in a real implementation, you'd use a search API
    return f"Search results for '{query}': [This would contain actual search results from a search API]"

def calculate(expression: str) -> str:
    """Safely calculate mathematical expressions"""
    try:
        # Basic safety check - only allow numbers, operators, and parentheses
        allowed_chars = set('0123456789+-*/()., ')
        if not all(c in allowed_chars for c in expression):
            return "Error: Invalid characters in expression"
        
        result = eval(expression)
        return f"Result: {result}"
    except Exception as e:
        return f"Error calculating: {e}"

def get_current_time() -> str:
    """Get the current date and time"""
    return f"Current time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

def list_openrouter_models(category: str = "all") -> str:
    """List available OpenRouter models by category"""
    # Load our top 100 models
    try:
        import pandas as pd
        import glob
        
        # Look for models data in the data directory
        data_dir = os.path.join(os.path.dirname(__file__), '..', 'data')
        csv_files = glob.glob(os.path.join(data_dir, 'top_100_openrouter_models_*.csv'))
        
        if not csv_files:
            # Fallback to current directory
            csv_files = glob.glob('top_100_openrouter_models_*.csv')
        
        if not csv_files:
            return "Error: Top 100 models data not found. Please ensure the data files are in the data/ directory."
        
        df = pd.read_csv(max(csv_files))
        
        if category == "free":
            models = df[df['is_free'] == True]
        elif category == "programming":
            models = df[df['id'].str.contains('code|dev|programming', case=False, na=False)]
        elif category == "reasoning":
            models = df[df['id'].str.contains('reasoning|think|r1|o1', case=False, na=False)]
        elif category == "fast":
            models = df[df['id'].str.contains('flash|fast|lite|mini', case=False, na=False)]
        else:
            models = df.head(20)  # Top 20 for "all"
        
        result = f"OpenRouter Models ({category}):\n"
        for _, model in models.head(10).iterrows():
            cost = "FREE" if model['is_free'] else f"${model['input_cost']:.4f}/M"
            result += f"- {model['id']} (Score: {model['total_score']:.1f}, Cost: {cost})\n"
        
        return result
    except Exception as e:
        return f"Error listing models: {e}"

# Register all tools
tool_registry.register_tool("write_file", write_file, 
    "write_file(filename: str, content: str) -> str - Write content to a file")

tool_registry.register_tool("read_file", read_file,
    "read_file(filename: str) -> str - Read content from a file")

tool_registry.register_tool("search_web", search_web,
    "search_web(query: str) -> str - Search the web for information")

tool_registry.register_tool("calculate", calculate,
    "calculate(expression: str) -> str - Calculate mathematical expressions")

tool_registry.register_tool("get_current_time", get_current_time,
    "get_current_time() -> str - Get the current date and time")

tool_registry.register_tool("list_openrouter_models", list_openrouter_models,
    "list_openrouter_models(category: str = 'all') -> str - List OpenRouter models by category (all, free, programming, reasoning, fast)")

# ============================================================================
# MASTER PROMPT TEMPLATE
# ============================================================================

MASTER_PROMPT_TEMPLATE = """You are a helpful, autonomous AI agent. Your goal is to solve the user's request by breaking it down and using the available tools.

You have access to the following tools:
{tool_schemas}

Follow this exact format for your responses:
Thought: Your step-by-step reasoning about what you need to do next.
Action: The name of the single tool to use from the list above.
Action Input: The parameters for the chosen tool in the format: param1="value1", param2="value2"
Observation: (This is filled in by the system after the tool runs)

If you have enough information to answer the user's request, you MUST respond with:
Final Answer: Your final, complete response to the user.

Important guidelines:
- Always think step by step before taking action
- Use tools to gather information or perform tasks
- Only provide a Final Answer when you have sufficient information
- If a tool fails, try alternative approaches
- Be thorough and accurate in your responses

Begin!
User's Request: {user_request}"""

# ============================================================================
# AI AGENT CLASS
# ============================================================================

class AIAgent:
    """Main AI Agent class implementing the ReAct pattern"""
    
    def __init__(self, model_name: str = "anthropic/claude-3.5-sonnet", api_key: str = None):
        """Initialize the AI Agent"""
        self.client = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=api_key or os.getenv("OPENROUTER_API_KEY"),
        )
        self.model = model_name
        self.history: List[Dict[str, str]] = []
        self.max_iterations = 10
        self.tool_registry = tool_registry
        
        logger.info(f"Initialized AI Agent with model: {model_name}")
    
    def run(self, user_request: str) -> str:
        """Run the agent to solve the user's request"""
        logger.info(f"Starting agent run for request: {user_request[:100]}...")
        
        # Format the initial prompt
        master_prompt = MASTER_PROMPT_TEMPLATE.format(
            tool_schemas=self.tool_registry.get_tool_schemas(),
            user_request=user_request
        )
        
        self.history = [{"role": "user", "content": master_prompt}]
        
        # Main reasoning loop
        for iteration in range(self.max_iterations):
            logger.info(f"--- Iteration {iteration + 1} ---")
            
            try:
                # Call the LLM
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=self.history,
                    temperature=0.1,
                    max_tokens=2000
                )
                
                llm_output = response.choices[0].message.content
                self.history.append({"role": "assistant", "content": llm_output})
                
                logger.info(f"LLM Response:\n{llm_output}")
                
                # Check for Final Answer
                if "Final Answer:" in llm_output:
                    final_answer = llm_output.split("Final Answer:")[-1].strip()
                    logger.info("Task completed successfully!")
                    return final_answer
                
                # Parse and execute action
                tool_result = self._parse_and_execute_action(llm_output)
                
                # Add observation to history
                observation = f"Observation: {tool_result.result}"
                if not tool_result.success and tool_result.error:
                    observation += f" (Error: {tool_result.error})"
                
                logger.info(f"Tool Result: {observation}")
                self.history.append({"role": "user", "content": observation})
                
            except Exception as e:
                logger.error(f"Error in iteration {iteration + 1}: {e}")
                error_msg = f"Observation: System error occurred: {e}. Please try a different approach."
                self.history.append({"role": "user", "content": error_msg})
        
        logger.warning("Maximum iterations reached without completion")
        return "I apologize, but I wasn't able to complete the task within the maximum number of iterations. Please try rephrasing your request or breaking it down into smaller parts."
    
    def _parse_and_execute_action(self, llm_output: str) -> ToolResult:
        """Parse the LLM output and execute the requested action"""
        
        # Extract Action and Action Input
        action_match = re.search(r"Action:\s*(\w+)", llm_output)
        input_match = re.search(r"Action Input:\s*(.+?)(?=\n|$)", llm_output, re.DOTALL)
        
        if not action_match:
            return ToolResult(False, "", "No valid action found in response")
        
        tool_name = action_match.group(1)
        
        if not input_match:
            return ToolResult(False, "", "No action input found in response")
        
        tool_input_str = input_match.group(1).strip()
        
        # Parse tool parameters
        try:
            # Simple parameter parsing - handles key="value" format
            params = {}
            
            # Handle simple cases first
            if '=' not in tool_input_str:
                # Single parameter without key
                params = {'query': tool_input_str.strip('"')} if tool_name == 'search_web' else {}
            else:
                # Parse key=value pairs
                param_pattern = r'(\w+)=(["\'])(.*?)\2|(\w+)=([^,\s]+)'
                matches = re.findall(param_pattern, tool_input_str)
                
                for match in matches:
                    if match[0]:  # Quoted value
                        params[match[0]] = match[2]
                    elif match[3]:  # Unquoted value
                        params[match[3]] = match[4]
            
            # Execute the tool
            return self.tool_registry.execute_tool(tool_name, **params)
            
        except Exception as e:
            logger.error(f"Error parsing tool input '{tool_input_str}': {e}")
            return ToolResult(False, "", f"Error parsing tool parameters: {e}")

# ============================================================================
# EXAMPLE USAGE AND TESTING
# ============================================================================

def test_agent():
    """Test the AI agent with sample requests"""
    
    # Check for API key
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        print("Warning: OPENROUTER_API_KEY not set. Please set it to test the agent.")
        return
    
    agent = AIAgent()
    
    test_requests = [
        "What are the top 5 free OpenRouter models for programming tasks?",
        "Calculate the result of 15 * 23 + 47 and write it to a file called 'calculation.txt'",
        "What time is it right now?",
    ]
    
    for i, request in enumerate(test_requests, 1):
        print(f"\n{'='*60}")
        print(f"Test {i}: {request}")
        print('='*60)
        
        try:
            result = agent.run(request)
            print(f"\nResult: {result}")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    test_agent()

