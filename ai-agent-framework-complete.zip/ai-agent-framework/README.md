# 🤖 AI Agent Framework

[![Python 3.7+](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![OpenRouter](https://img.shields.io/badge/OpenRouter-Integrated-green.svg)](https://openrouter.ai)

A complete AI agent framework built from first principles using the **ReAct (Reason + Act)** pattern with OpenRouter integration. Access the top 100 AI models through a unified, extensible interface.

## ✨ Features

- 🧠 **ReAct Pattern Implementation**: Step-by-step reasoning with tool execution
- 🏆 **Top 100 OpenRouter Models**: Curated selection of the best AI models
- 🔧 **Extensible Tool System**: Easy to add custom tools and capabilities
- 🔄 **Multiple Model Support**: Switch between different AI models seamlessly
- 🎮 **Interactive Demo**: Ready-to-use interactive application
- 📊 **Comprehensive Analysis**: Model rankings and performance data
- 🚀 **Production Ready**: Error handling, logging, and retry logic

## 🚀 Quick Start

### 1. Clone and Install

```bash
git clone https://github.com/yourusername/ai-agent-framework.git
cd ai-agent-framework
pip install -r requirements.txt
```

### 2. Set Your API Key

```bash
export OPENROUTER_API_KEY="your-openrouter-api-key"
```

Get your API key at [openrouter.ai](https://openrouter.ai)

### 3. Run the Interactive Demo

```bash
python examples/interactive_demo.py
```

### 4. Basic Usage

```python
from src.ai_agent_framework import AIAgent

# Initialize the agent
agent = AIAgent(model_name="anthropic/claude-3.5-sonnet")

# Run a task
result = agent.run("What are the top 5 free OpenRouter models for programming?")
print(result)
```

## 📁 Project Structure

```
ai-agent-framework/
├── src/
│   └── ai_agent_framework.py    # Core framework implementation
├── examples/
│   └── interactive_demo.py      # Interactive demo application
├── data/
│   ├── top_100_openrouter_models_*.csv    # Model rankings data
│   ├── openrouter_analysis_*.json         # Detailed analysis
│   └── top_100_summary_*.md              # Human-readable summary
├── tests/                       # Unit tests (coming soon)
├── docs/                       # Documentation
├── requirements.txt            # Python dependencies
├── setup.py                   # Package setup
└── README.md                  # This file
```

## 🏗️ Architecture

### Core Components

1. **The Brain (LLM)**: OpenRouter AI models for reasoning
2. **The Engine**: Python loop implementing ReAct pattern  
3. **The Toolbelt**: Extensible collection of tools

### Key Classes

- `AIAgent`: Main agent class implementing the ReAct loop
- `ToolRegistry`: Manages available tools and their execution
- `ToolResult`: Standardized result format for tool execution

## 🛠️ Available Tools

### Built-in Tools

| Tool | Description | Example Usage |
|------|-------------|---------------|
| `write_file` | Write content to a file | Write a Python script to file |
| `read_file` | Read content from a file | Read configuration file |
| `search_web` | Search the web for information | Find latest AI news |
| `calculate` | Perform mathematical calculations | Calculate complex expressions |
| `get_current_time` | Get current date and time | Check current timestamp |
| `list_openrouter_models` | List available models by category | Find best free models |

### Extended Tools (Demo)

| Tool | Description | Example Usage |
|------|-------------|---------------|
| `create_story` | Generate creative stories | Write adventure story |
| `analyze_text` | Analyze text for sentiment/stats | Sentiment analysis |
| `manage_todo_list` | Manage a todo list | Add/list/clear todos |
| `get_model_recommendation` | Get model recommendations | Find best model for coding |

## 📊 Top 100 OpenRouter Models

Our framework includes a curated selection of the top 100 OpenRouter models, scored based on:

- **Usage Score (25%)**: Actual usage rankings from OpenRouter
- **Programming Score (20%)**: Performance in coding tasks
- **Cost Score (15%)**: Free models and cost-effectiveness  
- **Context Score (15%)**: Context window length
- **Provider Score (15%)**: Provider reputation and market share
- **Capability Score (10%)**: Special features (multimodal, reasoning, etc.)

### 🏆 Top 10 Models

1. **anthropic/claude-3.5-sonnet** (Score: 77.8) - Best overall performance
2. **google/gemini-2.5-flash** (Score: 63.1) - Fast and capable
3. **google/gemini-2.5-pro** (Score: 50.1) - High-quality responses
4. **deepseek/deepseek-r1-0528:free** (Score: 40.7) - Best free reasoning model
5. **openai/gpt-4.1** (Score: 40.4) - Latest GPT model
6. **anthropic/claude-3.7-sonnet** (Score: 35.2) - Advanced reasoning
7. **deepseek/deepseek-v3-0324:free** (Score: 35.0) - Excellent free option
8. **google/gemini-pro-1.5** (Score: 44.8) - Reliable performance
9. **openai/gpt-4.1-mini** (Score: 40.4) - Cost-effective GPT
10. **anthropic/claude-3.7-sonnet:thinking** (Score: 35.2) - Thinking model

### 📂 Model Categories

- **Programming & Code**: Best for software development tasks
- **Free Models**: High-quality models at no cost
- **High Context (>100K)**: For processing long documents
- **Reasoning & Thinking**: Specialized reasoning capabilities
- **Fast & Efficient**: Quick response times
- **Enterprise & Production**: Reliable for business use

## 🔧 Adding Custom Tools

```python
from src.ai_agent_framework import tool_registry

def my_custom_tool(param1: str, param2: int = 10) -> str:
    """Your custom tool implementation"""
    return f"Processed {param1} with value {param2}"

# Register the tool
tool_registry.register_tool(
    "my_custom_tool",
    my_custom_tool,
    "my_custom_tool(param1: str, param2: int = 10) -> str - Description of what it does"
)
```

## 💡 Example Use Cases

### Programming Assistant
```python
agent = AIAgent("deepseek/deepseek-v3-0324:free")
result = agent.run("Create a Python function to calculate fibonacci numbers and save it to fib.py")
```

### Content Creation
```python
agent = AIAgent("anthropic/claude-3.5-sonnet")
result = agent.run("Write a blog post about AI agents and save it to blog.md")
```

### Data Analysis
```python
agent = AIAgent("google/gemini-2.5-pro")
result = agent.run("Analyze the sentiment of this text: 'I love using AI agents!'")
```

### Research Assistant
```python
agent = AIAgent("anthropic/claude-3.5-sonnet")
result = agent.run("Research the latest developments in AI and create a summary")
```

## 🎯 Model Selection Guide

### For Programming
- **Free**: `deepseek/deepseek-v3-0324:free`
- **Premium**: `anthropic/claude-3.5-sonnet`

### For Writing
- **Creative**: `anthropic/claude-3.5-sonnet`
- **Technical**: `openai/gpt-4.1`

### For Analysis
- **Data**: `google/gemini-2.5-pro`
- **Text**: `anthropic/claude-3.5-sonnet`

### For Free Usage
- **Best Overall**: `deepseek/deepseek-v3-0324:free`
- **Reasoning**: `deepseek/deepseek-r1-0528:free`

## 🧪 Testing

### Run Interactive Demo
```bash
python examples/interactive_demo.py interactive
```

### Run Batch Tests
```bash
python examples/interactive_demo.py test
```

### Example Requests to Try
- "What are the best free OpenRouter models for programming?"
- "Create an adventure story about a magical forest and save it to a file"
- "Calculate 25 * 17 + 83 and analyze the sentiment of the result"
- "Add 'Learn Python' to my todo list and then show me the full list"

## 🔍 Troubleshooting

### Common Issues

**API Key Not Set**
```bash
export OPENROUTER_API_KEY="your-key-here"
```

**Module Import Errors**
```bash
pip install -r requirements.txt
```

**Model Not Available**
- Check model name spelling
- Try an alternative model from our top 100 list

## 📚 Advanced Configuration

### Custom Agent Settings
```python
agent = AIAgent(
    model_name="anthropic/claude-3.5-sonnet",
    api_key="your-key"
)
agent.max_iterations = 15  # Increase for complex tasks
```

### Environment Variables
```bash
export OPENROUTER_API_KEY="your-api-key"
export AI_AGENT_LOG_LEVEL="INFO"  # DEBUG, INFO, WARNING, ERROR
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [OpenRouter](https://openrouter.ai) for providing unified access to AI models
- The AI community for advancing the ReAct pattern research
- All contributors to this project

## 📞 Support

- 📧 Email: support@ai-agent-framework.com
- 💬 Discord: [Join our community](https://discord.gg/ai-agents)
- 📖 Documentation: [Full docs](https://ai-agent-framework.readthedocs.io)
- 🐛 Issues: [GitHub Issues](https://github.com/yourusername/ai-agent-framework/issues)

---

**Ready to build your own AI agent?** 🚀 Start with the interactive demo and explore the possibilities!

